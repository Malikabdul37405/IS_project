package fileencryption;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;

public class EncryptionApp extends JFrame {
    private JTextField keyField;
    private JButton encryptButton, decryptButton;
    private JFileChooser fileChooser;
    private JLabel statusLabel;
    private JList<String> fileList;
    private DefaultListModel<String> listModel;
    private ArrayList<String> encryptedFiles;

    public EncryptionApp() {
        // Initialize encrypted files list
        encryptedFiles = new ArrayList<>();
        
        // Set the title and size of the JFrame window
        setTitle("File Encryption & Decryption");
        setSize(700, 500); // Larger window
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Center the window on the screen

        // Create a panel for holding components with padding
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        // Create components
        JLabel keyLabel = new JLabel("Enter Secret Key (16 characters):");
        keyLabel.setFont(new Font("Arial", Font.BOLD, 16)); // Make label text bigger
        keyField = new JTextField(20);
        keyField.setFont(new Font("Arial", Font.PLAIN, 16)); // Increase font size of text field

        encryptButton = new JButton("Encrypt File");
        encryptButton.setFont(new Font("Arial", Font.PLAIN, 14)); // Make button text bigger

        decryptButton = new JButton("Decrypt File");
        decryptButton.setFont(new Font("Arial", Font.PLAIN, 14)); // Make button text bigger

        statusLabel = new JLabel("Status: Waiting for user input...");
        statusLabel.setFont(new Font("Arial", Font.ITALIC, 14)); // Add status message
        statusLabel.setForeground(Color.BLUE);

        fileChooser = new JFileChooser();

        // File list to show encrypted files
        listModel = new DefaultListModel<>();
        fileList = new JList<>(listModel);
        fileList.setFont(new Font("Arial", Font.PLAIN, 14));
        fileList.setVisibleRowCount(10);
        fileList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane listScrollPane = new JScrollPane(fileList);

        // Add components to the panel with proper alignment
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        panel.add(keyLabel, gbc);

        gbc.gridy++;
        panel.add(keyField, gbc);

        gbc.gridy++;
        gbc.gridwidth = 1;
        panel.add(encryptButton, gbc);

        gbc.gridx++;
        panel.add(decryptButton, gbc);

        gbc.gridx = 0;
        gbc.gridy++;
        gbc.gridwidth = 2;
        panel.add(statusLabel, gbc);

        gbc.gridy++;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.BOTH;
        panel.add(listScrollPane, gbc);

        // Add the panel to the frame
        add(panel);

        // Button Actions
        encryptButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                handleFileEncryption(true);
            }
        });

        decryptButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                handleFileEncryption(false);
            }
        });
    }

    // Method to handle encryption and decryption
    private void handleFileEncryption(boolean isEncrypt) {
        String key = keyField.getText();
        if (key.length() != 16) {
            JOptionPane.showMessageDialog(this, "Error: Key must be 16 characters long!", "Invalid Key", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int returnVal = fileChooser.showOpenDialog(this);
        if (returnVal == JFileChooser.APPROVE_OPTION) {
            String filePath = fileChooser.getSelectedFile().getAbsolutePath();
            String fileName = fileChooser.getSelectedFile().getName();

            if (isEncrypt) {
                FileEncryption.encryptFile(filePath, key);
                statusLabel.setText("Status: File encrypted successfully!");

                // Add to the encrypted files list and GUI list
                if (!encryptedFiles.contains(fileName)) {
                    encryptedFiles.add(fileName);
                    listModel.addElement(fileName + " (Encrypted)");
                }
            } else {
                if (encryptedFiles.contains(fileName)) {
                    FileEncryption.decryptFile(filePath, key);
                    statusLabel.setText("Status: File decrypted successfully!");
                    encryptedFiles.remove(fileName);

                    // Update GUI list
                    listModel.removeElement(fileName + " (Encrypted)");
                    listModel.addElement(fileName + " (Decrypted)");
                } else {
                    JOptionPane.showMessageDialog(this, "File not found in encrypted list.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        } else {
            statusLabel.setText("Status: No file selected.");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            EncryptionApp app = new EncryptionApp();
            app.setVisible(true);
        });
    }
}
