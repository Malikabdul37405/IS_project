package fileencryption;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.file.Files;
import java.util.Base64;
import javax.swing.JOptionPane;

public class FileEncryption {
    
    private static final String ALGORITHM = "AES";
    
    public static void encryptFile(String filePath, String key) {
        try {
            byte[] keyBytes = key.getBytes("UTF-8");
            SecretKeySpec secretKey = new SecretKeySpec(keyBytes, ALGORITHM);
            
            Cipher cipher = Cipher.getInstance(ALGORITHM);
            cipher.init(Cipher.ENCRYPT_MODE, secretKey);
            
            File inputFile = new File(filePath);
            byte[] fileData = Files.readAllBytes(inputFile.toPath());
            byte[] encryptedData = cipher.doFinal(fileData);
            
            FileOutputStream outputStream = new FileOutputStream(inputFile);
            outputStream.write(encryptedData);
            outputStream.close();
            
            JOptionPane.showMessageDialog(null, "File Encrypted Successfully!");
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error encrypting file!");
        }
    }
    
    public static void decryptFile(String filePath, String key) {
        try {
            byte[] keyBytes = key.getBytes("UTF-8");
            SecretKeySpec secretKey = new SecretKeySpec(keyBytes, ALGORITHM);
            
            Cipher cipher = Cipher.getInstance(ALGORITHM);
            cipher.init(Cipher.DECRYPT_MODE, secretKey);
            
            File inputFile = new File(filePath);
            byte[] fileData = Files.readAllBytes(inputFile.toPath());
            byte[] decryptedData = cipher.doFinal(fileData);
            
            FileOutputStream outputStream = new FileOutputStream(inputFile);
            outputStream.write(decryptedData);
            outputStream.close();
            
            JOptionPane.showMessageDialog(null, "File Decrypted Successfully!");
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error decrypting file!");
        }
    }
}
